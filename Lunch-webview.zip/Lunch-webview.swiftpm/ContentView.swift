import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    let webView: WKWebView
    
    func makeUIView(context: Context) -> WKWebView {
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        // 無需更新
    }
}

struct ContentView: View {
    @State private var webView = WKWebView()
    @State private var showShareSheet = false
    @State private var showExportView = false
    @State private var isLongPressing = false
    
    let url = URL(string: "https://ian20040409.github.io/Lunch-Navigator-web-2025/")!
    
    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            WebView(webView: webView)
                .onAppear {
                    let request = URLRequest(url: url)
                    webView.load(request)
                }
            
            // 藥丸型側邊工具列（右下）
            VStack(spacing: 20) {
                Button(action: {
                    if webView.canGoBack {
                        webView.goBack()
                    }
                }) {
                    Image(systemName: "chevron.left")
                }
                
                Button(action: {
                    if webView.canGoForward {
                        webView.goForward()
                    }
                }) {
                    Image(systemName: "chevron.right")
                }
                
                Button(action: {
                    webView.reload()
                }) {
                    Image(systemName: "arrow.clockwise")
                }
                
                // 分享按鈕 + 長按觸發 ExportView
                Button(action: {
                    showShareSheet = true
                }) {
                    Image(systemName: "square.and.arrow.up")
                        .scaleEffect(isLongPressing ? 1.3 : 1.0)
                        .animation(.easeInOut(duration: 0.2), value: isLongPressing)
                }
                .simultaneousGesture(
                    LongPressGesture(minimumDuration: 1.5)
                        .onChanged { _ in
                            withAnimation {
                                isLongPressing = true
                            }
                        }
                        .onEnded { _ in
                            isLongPressing = false
                            showExportView = true
                        }
                )
            }
            .padding()
            .background(.ultraThinMaterial)
            .clipShape(Capsule())
            .padding(.trailing, 20)
            .padding(.bottom, 40)
            .shadow(radius: 5)
        }
        .ignoresSafeArea(.all, edges: .bottom)
        .sheet(isPresented: $showShareSheet) {
            if let shareURL = webView.url {
                ShareSheet(activityItems: [shareURL])
            }
        }
        .sheet(isPresented: $showExportView) {
            ExportView()
        }
    }
}

// UIKit 的分享控制器包裝
struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
